/**
 * Background Script pour l'extension Password Manager
 * Gère la communication avec le Native Messaging Host
 */

// Connexion au native messaging host
let nativePort = null;
let isConnected = false;

/**
 * Initialise la connexion au native host
 */
function connectNativeHost() {
  try {
    nativePort = browser.runtime.connectNative("com.passwordmanager.native");
    
    nativePort.onMessage.addListener((message) => {
      console.log("Message reçu du native host:", message);
      handleNativeMessage(message);
    });
    
    nativePort.onDisconnect.addListener(() => {
      console.error("Déconnexion du native host:", browser.runtime.lastError);
      isConnected = false;
      nativePort = null;
      
      // Tentative de reconnexion après 5 secondes
      setTimeout(connectNativeHost, 5000);
    });
    
    isConnected = true;
    console.log("Connecté au native host");
    
    // Test de connexion
    sendToNativeHost({ action: "ping" });
    
  } catch (error) {
    console.error("Erreur de connexion au native host:", error);
    isConnected = false;
  }
}

/**
 * Envoie un message au native host
 */
function sendToNativeHost(message) {
  if (!isConnected || !nativePort) {
    console.error("Pas de connexion au native host");
    return Promise.reject(new Error("Not connected to native host"));
  }
  
  return new Promise((resolve, reject) => {
    const messageId = Date.now() + Math.random();
    message.messageId = messageId;
    
    // Timeout après 10 secondes
    const timeout = setTimeout(() => {
      reject(new Error("Timeout waiting for response"));
    }, 10000);
    
    // Écouter la réponse
    const listener = (response) => {
      if (response.messageId === messageId || response.status) {
        clearTimeout(timeout);
        nativePort.onMessage.removeListener(listener);
        resolve(response);
      }
    };
    
    nativePort.onMessage.addListener(listener);
    nativePort.postMessage(message);
  });
}

/**
 * Gère les messages reçus du native host
 */
function handleNativeMessage(message) {
  // Diffuser le message aux content scripts si nécessaire
  browser.tabs.query({active: true, currentWindow: true}).then(tabs => {
    if (tabs[0]) {
      browser.tabs.sendMessage(tabs[0].id, {
        type: "nativeResponse",
        data: message
      }).catch(err => console.log("Tab not ready for messages"));
    }
  });
}

/**
 * Gère les messages des content scripts
 */
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Message reçu:", message);
  
  switch (message.type) {
    case "searchCredentials":
      sendToNativeHost({
        action: "search_credentials",
        url: message.url
      })
      .then(response => sendResponse(response))
      .catch(error => sendResponse({ status: "error", error: error.message }));
      return true; // Indique une réponse asynchrone
      
    case "getCredentials":
      sendToNativeHost({
        action: "get_credentials",
        entry_id: message.entryId
      })
      .then(response => sendResponse(response))
      .catch(error => sendResponse({ status: "error", error: error.message }));
      return true;
      
    case "saveCredentials":
      sendToNativeHost({
        action: "save_credentials",
        url: message.url,
        username: message.username,
        password: message.password,
        title: message.title
      })
      .then(response => sendResponse(response))
      .catch(error => sendResponse({ status: "error", error: error.message }));
      return true;
      
    case "generatePassword":
      sendToNativeHost({
        action: "generate_password",
        length: message.length || 20
      })
      .then(response => sendResponse(response))
      .catch(error => sendResponse({ status: "error", error: error.message }));
      return true;
      
    case "checkStatus":
      sendToNativeHost({
        action: "check_status"
      })
      .then(response => sendResponse(response))
      .catch(error => sendResponse({ status: "error", error: error.message }));
      return true;
      
    default:
      console.warn("Type de message inconnu:", message.type);
      sendResponse({ status: "error", error: "Unknown message type" });
  }
});

/**
 * Gère les clics sur l'icône de l'extension
 */
browser.browserAction.onClicked.addListener((tab) => {
  // Le popup s'ouvrira automatiquement grâce à default_popup dans manifest.json
  console.log("Extension icon clicked");
});

// Initialisation au démarrage
connectNativeHost();

// Ping régulier pour maintenir la connexion
setInterval(() => {
  if (isConnected) {
    sendToNativeHost({ action: "ping" }).catch(err => {
      console.error("Ping failed:", err);
    });
  }
}, 30000); // Toutes les 30 secondes

console.log("Background script initialisé");
